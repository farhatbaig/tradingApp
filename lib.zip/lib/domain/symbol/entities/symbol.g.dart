// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'symbol.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$SymbolDataImpl _$$SymbolDataImplFromJson(Map<String, dynamic> json) =>
    _$SymbolDataImpl(
      symbol: json['symbol'] as String,
    );

Map<String, dynamic> _$$SymbolDataImplToJson(_$SymbolDataImpl instance) =>
    <String, dynamic>{
      'symbol': instance.symbol,
    };
