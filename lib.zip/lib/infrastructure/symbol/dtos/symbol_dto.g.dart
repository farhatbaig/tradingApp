// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'symbol_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_$SymbolDataDtoImpl _$$SymbolDataDtoImplFromJson(Map<String, dynamic> json) =>
    _$SymbolDataDtoImpl(
      symbol: json['symbol'] as String,
    );

Map<String, dynamic> _$$SymbolDataDtoImplToJson(_$SymbolDataDtoImpl instance) =>
    <String, dynamic>{
      'symbol': instance.symbol,
    };
